var fs = require("fs");
console.log("jj")
for(var num = 0;num < 30;num++)
{
fs.writeFileSync(`./text${num}.mcfunction`,`schedule function a:game/teach/text${num+1} 2s`)
}