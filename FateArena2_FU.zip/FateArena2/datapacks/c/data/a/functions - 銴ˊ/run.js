var fs = require("fs")
const { isNumber } = require("util")
fs.readdirSync("./damage").forEach(file => {
    var content = fs.readFileSync(`./damage/${file}`,"utf-8")
    var charname = ""
    content = content.replace("execute as @s[team=red]","execute as @s[team=red] unless score @s armor matches 1..")
    content = content.replace("execute as @s at @s","execute as @s at @s unless score @s armor matches 1..")
    content = content.replace("scoreboard players remove @s","execute unless score @s armor matches 1.. scoreboard players remove @s")
    content = content.replace("scoreboard players add @s tank","execute unless score @s armor matches 1.. scoreboard players add @s tank")
    content.split("\n").forEach(line=>{
        if(line.include("#") && isNaN(line.replace("#","")))
        {
            charname = line.replace("#","")
        }
    })
    fs.writeFileSync(`./damage/${file}`,content + "\nexecute as @s at @s run summon armor_stand ~ ~ ~ {Marker:1b,Silent:1,Tags:[\"\damage\"\],Invisible:1b,NoGravity:1b,CustomName:'{\"\text\"\:\"\-1 [Blind]\"\,\"\color\"\:\"\black\"\,\"\bold\"\:\"\true\"\}',CustomNameVisible:1b,DisabledSlots:4144959\}\
    " + `execute as @s[team=red] as @a[tag=blue${charname}] at @s run function a:damage/dealdmg \nexecute as @s[team=blue] as @a[tag=red${charname}] at @s run function a:damage/hitshield`)
})
        
