var fs = require("fs")
for(var i = 0;i<6;i++)
{
    fs.writeFileSync(`./${i}.mcfunction`,
    `
    execute as @s[team=red] positioned ^ ^ ^1 unless entity @a[team=blue,distance=..2] run function a:soulcrank/attray/${i+1}
    execute as @s[team=red] positioned ^ ^ ^1 at @a[team=blue,distance=..2] run particle dust 1 0 0 1 ~ ~ ~ 0.5 0.5 0.5 0 10 normal @s
    execute as @s[scores={ss=1..},team=red] positioned ^ ^ ^1 as @a[team=blue,distance=..2] at @s run function a:soulcrank/gotsa

    execute as @s[team=blue] positioned ^ ^ ^1 unless entity @a[team=red,distance=..2] run function a:soulcrank/attray/${i+1}
    execute as @s[team=blue] positioned ^ ^ ^1 at @a[team=red,distance=..2] run particle dust 1 0 0 1 ~ ~ ~ 0.5 1 0.5 0 10 normal @s
    execute as @s[scores={ss=1..},team=blue] positioned ^ ^ ^1 as @a[team=red,distance=..2] at @s run function a:soulcrank/gotsa
    
    `)
}