var fs = require("fs")
for(var i = 0;i<50;i++)
{
    fs.writeFileSync(`./${i}.mcfunction`,
    `
    particle dust 0 0 0 1 ~ ~ ~ 0 0 0 0 0 \n
    execute as @s[team=red] positioned ~-0.5 ~-1.25 ~-0.5 as @e[tag=player,dx=0,dy=0,dz=0,team=blue] at @s run function a:damage/40dmgsv\n

    execute as @s[team=blue] positioned ~-0.5 ~-1.25 ~-0.5 as @e[tag=player,dx=0,dy=0,dz=0,team=red] at @s run function a:damage/40dmgsv\n
    playsound minecraft:custom.ak ambient @a ~ ~ ~ 1
    execute as @s[team=red] positioned ~-0.5 ~-1.25 ~-0.5 unless entity @e[tag=player,distance=..2,team=blue] positioned ~0.5 ~1.25 ~0.5 if block ~ ~ ~ air positioned ^ ^ ^1 run function a:sverage/shoot/${i+1}
    execute as @s[team=blue] positioned ~-0.5 ~-1.25 ~-0.5 unless entity @e[tag=player,distance=..2,team=red] positioned ~0.5 ~1.25 ~0.5 if block ~ ~ ~ air positioned ^ ^ ^1 run function a:sverage/shoot/${i+1}

    `)
}