var fs = require("fs")
for(var i = 0;i<6;i++)
{
    fs.writeFileSync(`./${i}.mcfunction`,
    `
    execute as @s[team=red] positioned ^ ^ ^1 unless entity @e[tag=souldrop,tag=blues] run function a:soulcrank/sdray/${i+1}
    execute as @s[team=red] positioned ^ ^ ^1 at @e[tag=souldrop,tag=blues] run particle dust 1 0 0 1 ~ ~ ~ 0.5 0.5 0.5 0 10 normal @s
    execute as @s[scores={ss=1..},team=!blue] positioned ^ ^ ^1 as @e[tag=souldrop,tag=blues] at @s run function a:soulcrank/soulgotselected

    execute as @s[team=blue] positioned ^ ^ ^1 unless entity @e[tag=souldrop,tag=reds] run function a:soulcrank/sdray/${i+1}
    execute as @s[team=blue] positioned ^ ^ ^1 as @e[tag=souldrop,tag=reds] run particle dust 1 0 0 1 ~ ~ ~ 0.5 1 0.5 0 10 normal @s
    execute as @s[scores={ss=1..},team=!red] positioned ^ ^ ^1 as @e[tag=souldrop,tag=reds] at @s run function a:soulcrank/soulgotselected
    
    `)
}