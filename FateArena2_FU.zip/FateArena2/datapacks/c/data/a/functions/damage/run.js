execute as @s[team=red] as @a[tag=blue] at @s run function a:damage/hitshield 
 execute as @s[team=blue] as @a[tag=red] at @s run function a:damage/hitshield
