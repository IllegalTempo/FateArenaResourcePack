var fs = require("fs")
for(var i = 0;i<20;i++)
{
    fs.writeFileSync(`./${i}.mcfunction`,
    `
    execute as @s[team=red] positioned ^ ^ ^1 unless entity @a[team=!red,distance=..2] run function a:rune/rrwray/${i+1}
    execute as @s[team=red] positioned ^ ^ ^1 at @a[team=!red,distance=..2] run particle dust 1 1 0 1 ~ ~ ~ 0.5 0.5 0.5 0 100 normal @s
    execute as @s[scores={ss=1..},team=!blue] positioned ^ ^ ^1 as @a[team=!red,distance=..2] run function a:rune/rrw

    execute as @s[team=blue] positioned ^ ^ ^1 unless entity @a[team=!blue,distance=..2] run function a:rune/rrwray/${i+1}
    execute as @s[team=blue] positioned ^ ^ ^1 at @a[team=!blue,distance=..2] run particle dust 1 1 0 1 ~ ~ ~ 0.5 0.5 0.5 0 100 normal @s
    execute as @s[scores={ss=1..},team=!red] positioned ^ ^ ^1 as @a[team=!blue,distance=..2] run function a:rune/rrw
    
    `)
}