var fs = require("fs")
fs.readdirSync("./damage").forEach(file => {
    
    var content = fs.readFileSync(`./damage/${file}`,"utf-8")
    
    
        fs.writeFileSync(`./damage/${file}`,"execute as @s[tag=parry] at @s run function a:noihtys/parry\n" + content)
    })
   
    
    


