var fs = require("fs")
for(var i = 0;i<20;i++)
{
    fs.writeFileSync(`./${i}.mcfunction`,
    `
    particle dust 1 1 0 1 ~ ~ ~ 0.2 0 0.2 0 10 \n
    execute as @s[team=red] positioned ~-0.5 ~-1.25 ~-0.5 as @e[tag=player,dx=0,dy=0,dz=0,team=!red] at @s run function a:damage/20dmgsh\n

    execute as @s[team=blue] positioned ~-0.5 ~-1.25 ~-0.5 as @e[tag=player,dx=0,dy=0,dz=0,team=!blue] at @s run function a:damage/20dmgsh\n
    playsound minecraft:custom.electric ambient @a ~ ~ ~ 1 1.6
    execute as @s[team=red] positioned ~-0.5 ~-1.25 ~-0.5 unless entity @e[tag=player,dx=0,dy=0,dz=0,team=!red] positioned ~0.5 ~1.25 ~0.5 if block ~ ~ ~ air positioned ^ ^ ^1 run function a:renka/shoot/${i+1}
    execute as @s[team=blue] positioned ~-0.5 ~-1.25 ~-0.5 unless entity @e[tag=player,dx=0,dy=0,dz=0,team=!blue] positioned ~0.5 ~1.25 ~0.5 if block ~ ~ ~ air positioned ^ ^ ^1 run function a:renka/shoot/${i+1}

    `)
}