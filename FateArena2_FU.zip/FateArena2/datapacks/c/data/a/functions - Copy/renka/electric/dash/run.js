var fs = require("fs")
for(var i = 0;i<5;i++)
{
    fs.writeFileSync(`./${i}.mcfunction`,
    `
    particle dust 1 1 0 1 ~ ~ ~ 0.75 0 0.75 0 100 \n
    execute as @s[team=red] positioned ~-0.5 ~-0.5 ~-0.5 as @e[tag=player,dx=0,dy=0,dz=0,team=blue] at @s run function a:damage/20dmgsh\n

    execute as @s[team=blue] positioned ~-0.5 ~-0.5 ~-0.5 as @e[tag=player,dx=0,dy=0,dz=0,team=red] at @s run function a:damage/20dmgsh\n
    playsound minecraft:custom.electric ambient @a ~ ~ ~ 1 1.6
    execute positioned ~ ~1 ~ if block ^ ^ ^1 air run tp @s ^ ^ ^1
    execute positioned ~ ~1 ~ positioned ^ ^ ^1 run function a:renka/electric/dash/${i+1}

    `)
}