var fs = require("fs")
for(var i = 0;i<5;i++)
{
    fs.writeFileSync(`./${i}.mcfunction`,
    `
    particle dust 1 1 0 1 ~ ~ ~ 0.75 0 0.75 0 100 \n
    execute as @s[team=red] as @a[distance=..2,team=blue a:damage/20dmgsh\n
    execute as @s[team=red2] as @a[distance=..2,team=blue a:damage/20dmgsh\n

    execute as @s[team=blue] as @a[distance=..2,team=red a:damage/20dmgsh\n
    execute as @s[team=blue2] as @a[distance=..2,team=red a:damage/20dmgsh\n
    playsound minecraft:custom.electric ambient @a ~ ~ ~ 1 1.6
    execute positioned ~ ~1 ~ if block ^ ^ ^1 air run tp @s ^ ^ ^1
    execute positioned ~ ~1 ~ positioned ^ ^ ^1 run function a:renka/electric/dash/${i+1}

    `)
}