var fs = require("fs")
fs.readdirSync("./damage").forEach(file => {
    var content = fs.readFileSync(`./damage/${file}`,"utf-8")
    var charname =""
    content = content.replace("execute as @s[team=red]","execute as @s[team=red] unless score @s armor matches 1..")
    content = content.replace("execute as @s[team=blue]","execute as @s[team=blue] unless score @s armor matches 1..")

    content = content.replace("execute as @s at @s","execute as @s at @s unless score @s armor matches 1..")
    content = content.replace("scoreboard players remove @s","execute unless score @s armor matches 1.. run scoreboard players remove @s")
    content = content.replace("scoreboard players add @s tank","execute unless score @s armor matches 1.. run scoreboard players add @s tank")
    var lines = content.split("\n").forEach(line=>{
        if(line.includes("#") && isNaN(line.replace("#","")) && !line.includes(",")&& !line.includes(" "))
        {
            charname = line.replaceAll("#","").replaceAll(" ","").replaceAll("\n","")
    fs.writeFileSync(`./damage/${file}`,"#" + charname + content)

        }
    })
    

})
