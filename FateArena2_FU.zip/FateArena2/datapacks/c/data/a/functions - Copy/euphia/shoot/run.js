var fs = require("fs")
for(var i = 0;i<20;i++)
{
    fs.writeFileSync(`./${i}.mcfunction`,
    `
    particle dust 0.843 0.059 0.82 1 ~ ~ ~ 0.35 0.1 0.35 0 10\n
    particle minecraft:enchant ~ ~ ~ 0 0 0 0 10

    execute as @s[team=red] positioned ~-0.5 ~-1.25 ~-0.5 as @e[dx=0,dy=0,dz=0,team=blue,tag=player] at @s run function a:damage/5bdmg\n

    execute as @s[team=blue] positioned ~-0.5 ~-1.25 ~-0.5 as @e[dx=0,dy=0,dz=0,team=red,tag=player] at @s run function a:damage/5bdmg\n

    execute as @s[team=red] positioned ~-0.5 ~-1.25 ~-0.5 as @e[dx=0,dy=0,dz=0,team=red,tag=!redeuphia] at @s run function a:damage/15hdmg\n

    execute as @s[team=blue] positioned ~-0.5 ~-1.25 ~-0.5 as @e[dx=0,dy=0,dz=0,team=blue,tag=!blueeuphia] at @s run function a:damage/15hdmg\n
    playsound minecraft:block.enchantment_table.use ambient @a
    execute as @s[team=red] positioned ~-0.5 ~-1.25 ~-0.5 unless entity @e[dx=0,dy=0,dz=0,tag=!redeuphia,tag=player] positioned ~0.5 ~1.25 ~0.5 if block ~ ~ ~ #a:gothrough positioned ^ ^ ^1 run function a:euphia/shoot/${i+1}
    execute as @s[team=blue] positioned ~-0.5 ~-1.25 ~-0.5 unless entity @e[dx=0,dy=0,dz=0,tag=!blueeuphia,tag=player] positioned ~0.5 ~1.25 ~0.5 if block ~ ~ ~ #a:gothrough positioned ^ ^ ^1 run function a:euphia/shoot/${i+1}

    `)
}